package timeit.biz;

/**
 * 
 * @author Alejandro Duarte.
 *
 */
public interface Test {
	
	String getName();
	
	void execute();

}
