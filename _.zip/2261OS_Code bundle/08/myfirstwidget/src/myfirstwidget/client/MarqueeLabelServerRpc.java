package myfirstwidget.client;

import com.vaadin.shared.communication.ServerRpc;

public interface MarqueeLabelServerRpc extends ServerRpc {

  public void clicked();

}
