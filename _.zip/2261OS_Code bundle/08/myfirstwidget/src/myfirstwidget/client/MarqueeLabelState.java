package myfirstwidget.client;

import com.vaadin.shared.AbstractComponentState;

/**
 * 
 * @author Alejandro Duarte
 * 
 */
@SuppressWarnings("serial")
public class MarqueeLabelState extends AbstractComponentState {
  
  public String text = "";

}
