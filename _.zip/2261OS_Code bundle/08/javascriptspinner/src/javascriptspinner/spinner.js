javascriptspinner_Spinner = function() {
  var e = this.getElement();
  e.innerHTML = "<input id='spinner' />";
  var spinner = $("#spinner").spinner();
};
